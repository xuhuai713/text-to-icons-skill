---
name: text-to-icons
description: Convert user-provided text content (business processes, feature lists, categories, etc.) into matching linear icons, presented as an interactive HTML page with one-click SVG code copying. Default style: 1.5px stroke linear/outline icons.
agent_created: true
---

# Text to Icons

## Overview

This skill transforms textual content—process steps, feature lists, categories, or any structured text—into beautiful linear icons and renders them as a single self-contained HTML file. Each text item maps to **6 matching icons** drawn from a curated set of open-source icon libraries. The HTML includes one-click "Copy SVG" buttons for immediate reuse.

## 🔑 Critical Quality Rules (MUST FOLLOW)

Every icon in the output MUST pass ALL these checks:

1. **Instantly recognizable** — The average person must understand what the icon means within 1 second. If you have to squint or think about it, it fails.
2. **No abstract metaphors** — Only use icons that are universally understood visual symbols. A magnifying glass = search (good). A gear = settings (good). A pair of curvy lines as "handshake" (bad — looks like random squiggles).
3. **Must decode without labels** — Remove the text label and the icon should still be obvious.
4. **Vet your SVG paths** — Before including an icon, mentally trace the paths to ensure they actually draw what you think they draw. A "handshake" icon should clearly show two hands meeting, not abstract curves.
5. **No repetitions** — Within the same item's 6 icons, don't include two icons that look nearly the same (e.g., don't include both "search" and "search-alt").
6. **Path density check** — Reject any icon with more than 6 path elements (paths, lines, circles, rects, etc.) UNLESS every single element is clearly distinguishable at 28x28px. Dense icons with 7+ overlapping paths are illegible and MUST be replaced with simpler alternatives. Rule of thumb: if you can't trace each element at a glance, it fails.
7. **Shape integrity check** — Every geometric shape in the icon must be complete and correctly proportioned. Reject icons where:
   - Circles look squashed or off-center
   - Rectangles have mismatched corners
   - Lines don't connect where they visually should
   - Elements appear to overlap unintentionally ("杂糅")
8. **Visual weight balance** — The icon's strokes must be evenly distributed across the 24x24 viewBox. Reject icons where more than 70% of the strokes are crammed into one corner or side, leaving the rest empty — this creates a heavy, unbalanced appearance at small sizes.

## When to Use

- User provides a list of steps, stages, or phases (e.g., a business process flow, a product roadmap, a project lifecycle)
- User provides feature names, module names, or category labels and wants matching icons
- User says "帮我把这些内容转成图标" / "给这些步骤配上图标" / "convert this text to icons"
- User wants icons that can be copied as SVG code for use in design tools or frontend projects
- User explicitly requests linear/outline icons with 1.5px stroke style

## Workflow

### Step 1: Parse the Input

Extract all discrete items from the user's text. Items may be separated by:
- Newlines (each line is one item)
- Numbered or bulleted lists
- Comma-separated within a sentence
- Table rows

Preserve the original order. Output a numbered list for the user to confirm.

**Example input:**
```
线索挖掘, 商机洞察, 客户拜访, 营销推荐, 方案报价
```

**Parsed output:**
```
1. 线索挖掘
2. 商机洞察
3. 客户拜访
4. 营销推荐
5. 方案报价
```

### Step 2: Map Each Item to 6 Matching Icons (Critical Selection Process)

For each item, **painstakingly hand-pick 6 icons** that are immediately recognizable. This is the most important step.

**Icon selection process:**
1. First, identify the core concept of the item (e.g., "线索挖掘" = search/discovery)
2. Look at the reference catalog and mentally verify each candidate icon's paths
3. Reject any icon whose meaning isn't instantly clear
4. Select exactly 6 icons with DISTINCT visual forms (no similar-looking repeats)
5. Distribute across different sources (at least 3 different libraries)

**Quality benchmarks by category (what icons MUST look like):**
| Category | GOOD examples (instantly recognizable) | BAD examples (REJECT) |
|----------|--------------------------------------|----------------------|
| Search / Discovery | magnifying glass, compass, binoculars | abstract circles, squiggly lines |
| Data / Analysis / Insight | bar chart, line chart, pie chart, eye | brain, abstract geometry |
| People / User / Visit | single person, two people, group, phone, door | abstract "handshake" curves |
| Marketing / Promotion | megaphone, trophy, star, gift, thumbs-up | abstract badges |
| Price / Money / Quotation | dollar sign, coins, credit card, tag, wallet, calculator | abstract symbols |
| Contract / Document / Sign | file text, pen, clipboard, folder, book | ambiguous scroll shapes |
| Project / Task / Implement | clipboard check, flag, layers, target, check circle | abstract branching lines |
| Product / Config / Setup | box, gear, wrench, sliders, grid | abstract lattice |
| Activation / Launch | zap, play, power, plus, rocket | ambiguous arrows |
| Billing / Invoice | monitor, printer, bar chart, receipt, file invoice | abstract file shapes |
| Settlement / Cart | shopping cart, check, x mark, trash, ban | complex checkout flows |
| Completion / Done | check circle, check mark, award, archive, smile | ambiguous checkmarks |
| Service / Maintenance | wrench, tool, terminal, code | abstract gear-only |
| Risk / Security / Audit | shield, lock, warning, alert, search audit | abstract polygons |
| Training / Learning | book open, graduation cap, presentation, file badge | abstract head shapes |

For each item, pick 6 icons that cover distinct visual forms:
- **Literal symbols** (2-3): The most direct, obvious representation of the concept
- **Action/outcome** (2): Something related to the action or result
- **Tool/related object** (1-2): A commonly associated tool

**CRITICAL: Before finalizing any icon, mentally trace its SVG paths.** Make sure the paths actually draw what you think they draw. The "handshake" icon from the previous version was wrong — its SVG paths drew abstract curves that didn't look like hands at all. If the paths look like they might not render correctly, replace the icon.

For each item, the 6 icons should cover distinct visual forms:
- **Literal symbols** (2-3): The most direct, obvious representation
- **Action/outcome** (2): Something related to the action or result
- **Tool/related object** (1-2): A commonly associated tool

### Step 3: Generate the HTML Output

Generate a single self-contained HTML file with these requirements:

**Structure:**
- Single card/block per item with the item name and **6 icon options**
- Responsive grid layout (1 column on mobile, **6 columns for icons on desktop** — or 3 rows × 2 columns on tablet)
- Clean, professional design with subtle card styling

**Copy-to-clipboard feature:**
- Each icon has a "Copy SVG" button
- On click, copies the raw SVG code (with `<svg>` tag and all attributes) to clipboard
- Show a brief "已复制!" / "Copied!" feedback animation
- Use `navigator.clipboard.writeText()` with a `<textarea>` fallback

**SVG format rules:**
- Default: `stroke-width="1.5"`, `fill="none"`, `stroke="currentColor"`
- `stroke-linecap="round"` and `stroke-linejoin="round"` on SVG tag
- `viewBox="0 0 24 24"` standard size
- Width/height for display: `w-10 h-10` (Tailwind) or `width="40" height="40"`

**Icon source variety (must rotate across sources):**
| Source | License | Style Notes |
|--------|---------|-------------|
| Feather Icons | MIT | Clean, minimal, 24x24 |
| Lucide Icons | ISC | Feather-based, more options |
| Heroicons (Outline) | MIT | 24x24, rounded, friendly |
| Phosphor Icons | MIT | 24x24, slightly thicker feel |
| IconPark (ByteDance) | Apache 2.0 | 24x24, extensive library |

**Styling defaults:**
- Light theme (slate/white background)
- Tailwind CSS via CDN for layout (`<script src="https://cdn.tailwindcss.com"></script>`)
- Card hover: slight lift with shadow
- Copy button: border style, transitions smoothly to "Copied" state
- Step numbers displayed with gradient badges
- **Source attribution**: Each icon card should display a small tag/badge showing which icon library it comes from (e.g. `Feather`, `Lucide`, `Heroicons`, `Phosphor`, `IconPark`) — this builds user trust and clarifies licensing

### Step 4: Deliver

1. Write the HTML to `icons.html` in the workspace root
2. Use `preview_url` to show it in the browser
3. Summarize what was generated in text

## References Reference

Always load `references/icon-sources.md` into context when executing this skill. It contains the full icon catalog with SVG path data organized by semantic category, enabling rapid icon selection without external lookups.

## Fallback Behavior

- If an item has no obvious icon match in the reference catalog, use a generic icon (star, heart, bookmark) as the last option
- If the user provides fewer than 4 items, still generate 6 icons per item
- If the user provides more than 20 items, warn and ask to split into batches of 10

## Resources

### references/
- `icon-sources.md` — Full icon catalog organized by semantic category with SVG path data

### assets/
- (No assets needed — everything is generated programmatically)

### scripts/
- (No scripts needed — the icon mapping is done via reference lookup in context)
